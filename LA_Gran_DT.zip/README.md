# LA Gran DT — Generador de equivalencias

App web con Streamlit. Lee un Excel de OneDrive mediante enlace público, permite seleccionar filas y genera un archivo Word con una tabla de equivalencias ITBA ↔ POLIMI.

## Uso
1. Compartí el Excel con enlace de lectura.
2. Pegá el enlace en la app.
3. Elegí hoja y columnas.
4. Tildá las filas a incluir.
5. Descargá el DOCX.

## Estructura
- `app.py`
- `requirements.txt`